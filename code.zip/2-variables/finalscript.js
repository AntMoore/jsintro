let myName = "Ant Moore";
let age = 34;
let isSoftwareDeveloper = true;
let hasHair = false;
let heightCM = 175.25;
const yearOfBirth = 1991;

let meals = [
    "pie and chips",
    "mushroom risotto",
    "pasta and mince"
];

console.log(myName);
console.log("meals eaten this week", meals); 

console.log("hasHair", hasHair);
console.log("🪄");

hasHair = true;
console.log("hasHair", hasHair);

const eyeColour = "blue";
console.log("eyeColour", eyeColour);

eyeColour = "green";